<?php  
echo "<script>alert('Deixa de ser Idiota!');top.location.href='http://woodexport.com.br/home';</script>" ;
?>